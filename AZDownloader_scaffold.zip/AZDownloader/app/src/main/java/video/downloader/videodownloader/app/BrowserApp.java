package video.downloader.videodownloader.app;

import androidx.multidex.MultiDexApplication;

public class BrowserApp extends MultiDexApplication {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
